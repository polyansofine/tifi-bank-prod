export const LP_TOKENS = [
    {
        address: "0x707b6f02ffc0c7fd9fe3a4f392aef47218021337",
        name: "BNB-TIFI",
        token0_name: "BNB",
        token1_name: "TIFI",
    },
    {
        address: "0x76fc4931d9d3a2054aee2d59633e49b759277d69",
        name: "BNB-BUSD",
        token0_name: "BNB",
        token1_name: "BUSD",
    },
    {
        address: "0x35bcB082347DC28D3B7E28AbD383aFE653A6DADA",
        name: "BNB-USDT",
        token0_name: "BNB",
        token1_name: "USDT"
    }
];
